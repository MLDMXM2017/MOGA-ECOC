# MOGA-ECOC

Multi-Objective Genetic Algorithm Based Error Correcting Output Codes  
This is the implementation for paper: [A Novel Multi-Objective Genetic Algorithm Based Error Correcting Output Codes]

## Acknowledgement
- Codes about Genetic Algorithm is modified from [DEAP 1.3.0](https://deap.readthedocs.io/en/master/)
- Codes about Output-Code-Classifier is modified from [scikit-learn 0.22](https://scikit-learn.org/stable/)

## Environment
- **Windows 10 64 bit**
- **Python 3**
- **DEAP 1.3.0**  
DEAP is a novel evolutionary computation framework for rapid prototyping and testing of ideas. It seeks to make algorithms explicit and data structures transparent.  
You can install it by this way:  `easy_install deap` or `pip install deap`  
- **scikit-learn 0.22**  
[Anaconda](https://www.anaconda.com/) is strongly recommended, all necessary python packages for this project are included in the Anaconda.

## Function
By using the DEAP framwork, each steps of genetic algorithm can be realized.
- Initialization.intialization: create first generation
- Operate.crossover: cross matrix by column
- Operate.mutation: mutate individual by some bits on column
- PopLegality.checkMatrixsLegality: legalize matrix according to rules
- Valuate.calObjValue: calculate multi-objective f1-score/diversity/instance
- Operate.eliteRetention: keep elite

## Dataset
- **Data format**  
Data sets are put into the folder `($root_path)/data_uci`. All the data sets used in experiments are splited into three parts 
`xx_train.data`、`xx_validation.data` and `xx_test.data`. And the proportion of these three parts data are 2:1:1. 
These datasets are formed as follow. Each row represents a feature and each column represents an instance.  
The dataset put into the folder must have no null/nan/? value.
- **Data processing**
Feature Selection and Scaling will be done automatically.

## Runner Setup
We can run the `Runner.py` to use MOGA. As the paper mentioned, there are some runner modes can be used.  

The variable `base_learners` in the `Runner.py` can control the base classifiers in algorithm. 
If you use **Homogeneous Ensembles** you can put the only one classifier that you design in the variable.
If you use **Heterogeneous Ensembles** you can put many classifiers based in scikit-learn package in the variable at the same time.  

The three Objectives used to evaluate the matrix in the paper are f1score、distance and diversity between columns in the ECOC Matrix. 
If you want to adjust the proportion between these three objectives, you can reset it on `DeapSelect.py`.  

The results will be put into filefolder `records_NSGA`.
